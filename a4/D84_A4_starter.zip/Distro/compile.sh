g++ -fPIC -O3 -c -g NeuralNets.c
g++ -fPIC -O3 -g *.o -lm -o NeuralNets

